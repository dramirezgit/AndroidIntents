package mx.sati.tarea2androiddesign;

/**
 * Created by DANIEL RAMIREZ on 13/08/2016.
 */
public class Datos {
    private String nombre;
    private String telefono;
    private String email;
    private String comentarios;
    private String fecha;

    public Datos(String nombre,String telefono,String email,String comentarios,String fecha){
        this.nombre=nombre;
        this.telefono=telefono;
        this.email=email;
        this.comentarios=comentarios;
        this.fecha=fecha;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
}
