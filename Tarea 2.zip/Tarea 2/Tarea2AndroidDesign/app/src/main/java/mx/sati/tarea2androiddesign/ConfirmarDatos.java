package mx.sati.tarea2androiddesign;

import android.content.Intent;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class ConfirmarDatos extends AppCompatActivity {

    TextView nom;
    TextView Tel;
    TextView fech;
    TextView emil;
    TextView coment;
    Button editar;
    ArrayList<Datos> datos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.datos_confirmar);

        Bundle parametros = getIntent().getExtras();
        String nombre = "", telefono = "", email = "",comentarios="",fecha="";
        nombre = parametros.getString(getResources().getString(R.string.intnombre));
        telefono = parametros.getString(getResources().getString(R.string.inttel));
        email = parametros.getString(getResources().getString(R.string.intemail));
        comentarios = parametros.getString(getResources().getString(R.string.intdescrip));
        fecha = parametros.getString(getResources().getString(R.string.intfecha));

        nom = (TextView) findViewById(R.id.tvnomconf);
        Tel = (TextView) findViewById(R.id.tvtelconf);
        fech= (TextView) findViewById(R.id.tvfechconf);
        emil= (TextView) findViewById(R.id.tvemilconf);
        coment= (TextView) findViewById(R.id.tvdesconf);

        nom.setText(nombre);
        Tel.setText(telefono);
        fech.setText(fecha);
        emil.setText(email);
        coment.setText(comentarios);

        editar=(Button) findViewById(R.id.btneditar);

        editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datos= new ArrayList<Datos>();
                String result="1",nomb="",tele="",email="",comet="",fecha="";
                nom = (TextView) findViewById(R.id.tvnomconf);
                Tel = (TextView) findViewById(R.id.tvtelconf);
                fech= (TextView) findViewById(R.id.tvfechconf);
                emil= (TextView) findViewById(R.id.tvemilconf);
                coment= (TextView) findViewById(R.id.tvdesconf);
                nomb=nom.getText().toString();
                tele=Tel.getText().toString();
                email=emil.getText().toString();
                comet=coment.getText().toString();
                fecha=fech.getText().toString();
                datos.add(new Datos(nomb,tele,email,comet,fecha));
                Intent intent = new Intent(ConfirmarDatos.this,MainActivity.class);
                intent.putExtra(getResources().getString(R.string.intnombre),datos.get(0).getNombre());
                intent.putExtra(getResources().getString(R.string.inttel),datos.get(0).getTelefono());
                intent.putExtra(getResources().getString(R.string.intemail),datos.get(0).getEmail());
                intent.putExtra(getResources().getString(R.string.intdescrip),datos.get(0).getComentarios());
                intent.putExtra(getResources().getString(R.string.intfecha),datos.get(0).getFecha());
                startActivity(intent);
            }
        });


    }
}
