package mx.sati.tarea2androiddesign;

import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    //global campos
    TextInputEditText nombre;
    TextInputEditText telefono;
    TextInputEditText email;
    TextInputEditText comentarios;
    Button siguiente;
    DatePicker fecha;
    String resultValidacion="";
    ArrayList<Datos> datos;
    String fechaselected="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //obtener el dia, mes y año
        Calendar c= Calendar.getInstance();
        int year = c.get(c.YEAR);
        int month = c.get(c.MONTH);
        int dayOfMonth = c.get(c.DAY_OF_MONTH);

        fechaselected=month + "/" + dayOfMonth + "/" + year;

        fecha = (DatePicker) findViewById(R.id.dpfecha);

        fecha.init(year, month, dayOfMonth,new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(
                    DatePicker view,
                    int year,
                    int monthOfYear,
                    int dayOfMonth)
            {
                fechaselected=monthOfYear + "/" + dayOfMonth + "/" + year;
            }
        });
        //validacion campos
        siguiente=(Button) findViewById(R.id.btnsiguiente);
        siguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resultValidacion=validacion_campos(view);
                //si es valido envia a confirmar datos
                if(resultValidacion=="1"){
                    datos= new ArrayList<Datos>();
                    String result="1",nom="",tel="",emil="",com="",fech="";
                    nombre=(TextInputEditText) findViewById(R.id.tinom);
                    telefono=(TextInputEditText) findViewById(R.id.titel);
                    email=(TextInputEditText) findViewById(R.id.tiemail);
                    comentarios=(TextInputEditText) findViewById(R.id.tidesc);
                    nom=nombre.getText().toString();
                    tel=telefono.getText().toString();
                    emil=email.getText().toString();
                    com=comentarios.getText().toString();
                    fech=fechaselected;
                    datos.add(new Datos(nom,tel,emil,com,fech));
                    Intent intent =new Intent(MainActivity.this,ConfirmarDatos.class);
                    intent.putExtra(getResources().getString(R.string.intnombre),datos.get(0).getNombre());
                    intent.putExtra(getResources().getString(R.string.inttel),datos.get(0).getTelefono());
                    intent.putExtra(getResources().getString(R.string.intemail),datos.get(0).getEmail());
                    intent.putExtra(getResources().getString(R.string.intdescrip),datos.get(0).getComentarios());
                    intent.putExtra(getResources().getString(R.string.intfecha),datos.get(0).getFecha());
                    startActivity(intent);
                }
            }
        });
        //bundle
        Intent prueba =getIntent();
        if(prueba.hasExtra(getResources().getString(R.string.intnombre))) {
                Bundle parametros = getIntent().getExtras();
                String nombre1 = "", telefono1 = "", email1 = "", comentarios1 = "", fecha1 = "";
                nombre1 = parametros.getString(getResources().getString(R.string.intnombre));
                telefono1 = parametros.getString(getResources().getString(R.string.inttel));
                email1 = parametros.getString(getResources().getString(R.string.intemail));
                comentarios1 = parametros.getString(getResources().getString(R.string.intdescrip));
                fecha1 = parametros.getString(getResources().getString(R.string.intfecha));
                nombre = (TextInputEditText) findViewById(R.id.tinom);
                telefono = (TextInputEditText) findViewById(R.id.titel);
                email = (TextInputEditText) findViewById(R.id.tiemail);
                comentarios = (TextInputEditText) findViewById(R.id.tidesc);
                fecha = (DatePicker) findViewById(R.id.dpfecha);
                nombre.setText(nombre1);
                telefono.setText(telefono1);
                email.setText(email1);
                comentarios.setText(comentarios1);
                //split fecha
                String[] separated = fecha1.split("/");
                month = Integer.parseInt(separated[0]);
                dayOfMonth = Integer.parseInt(separated[1]);
                year = Integer.parseInt(separated[2]);
                Log.i("year",String.valueOf(year));
                fecha.updateDate(year,month,dayOfMonth);
        }
    }

    public String validacion_campos(View v){
        String result="1",nom="",tel="",emil="",com="";
        nombre=(TextInputEditText) findViewById(R.id.tinom);
        telefono=(TextInputEditText) findViewById(R.id.titel);
        email=(TextInputEditText) findViewById(R.id.tiemail);
        comentarios=(TextInputEditText) findViewById(R.id.tidesc);
        nom=nombre.getText().toString();
        tel=telefono.getText().toString();
        emil=email.getText().toString();
        com=comentarios.getText().toString();
        if(nom.equals("")){
            Snackbar.make(v,getResources().getString(R.string.validnom),Snackbar.LENGTH_SHORT).show();
            result="0";
        }
        else if(tel.equals("")){
            Snackbar.make(v,getResources().getString(R.string.validtel),Snackbar.LENGTH_SHORT).show();
            result="0";
        }
        else if(emil.equals("")){
            Snackbar.make(v,getResources().getString(R.string.validemail),Snackbar.LENGTH_SHORT).show();
            result="0";
        }
        else if(com.equals("")){
            Snackbar.make(v,getResources().getString(R.string.validcoment),Snackbar.LENGTH_SHORT).show();
            result="0";
        }
        return result;
    }
}
